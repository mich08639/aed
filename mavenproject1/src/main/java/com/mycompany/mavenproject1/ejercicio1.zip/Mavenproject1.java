/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject1;

/**
 *
 * @author mich0
 */
public class Mavenproject1 {

//  public  String 1nombrepellido; no puede comenzar con numero
   // public  String int; no puede tener palabras reservadas 
   // public  String nombre a; no puede tener espacios  

    public static String nombrAepellido;
    
    public int edad;
    
    public static void main(String[] args) {
            Mavenproject1 test = new Mavenproject1();
            System.out.println();
//            System.out.println(edad); no esta inicialisado 
            System.out.println(test.edad);
            String juan = "mich";
            System.out.println();
//            System.out.println(edad); no esta inicialisado 
            System.out.println(juan);
            
    }
}
